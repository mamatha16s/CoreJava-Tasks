import java.util.*;
class number1 {

	public static void main(String[] args) 
	{
	int num,i,j;
	Scanner s=new Scanner(System.in);
	System.out.println("enter the number to print sequence of numbers in triangle form");
	num=s.nextInt();
	for(i=0;i<=num;i++)
	{
		for(j=1;j<=i;j++)
		{
			System.out.print(j);
		}
		System.out.println("");
	}

	}

}
