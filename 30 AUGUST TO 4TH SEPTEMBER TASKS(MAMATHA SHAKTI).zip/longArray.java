import java.util.*;
public class longArray
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int a[]=new int[100];
		int b[]=new int[100];	
		System.out.println("enter first array length");
		int n1;
		n1=s.nextInt();
		System.out.println("enter elements of first array");
		for(int i=0;i<n1;i++)
			a[i]=s.nextInt();
		System.out.println("enter second array length");
		int n2;
		n2=s.nextInt();
		System.out.println("enter elements of second array");
		for(int i=0;i<n2;i++)
			b[i]=s.nextInt();
		if(n1>n2)
		{
			System.out.println("first array is longer");
			for(int i=0;i<n1;i++)
				System.out.println(" "+a[i]+",");
		}
		else
		{
			System.out.println("second array is longer");
			for(int i=0;i<n2;i++)
				System.out.println(" "+b[i]+",");
		}
	}

}
