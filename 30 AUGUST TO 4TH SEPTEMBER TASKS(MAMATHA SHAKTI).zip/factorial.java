import java.util.*;
class factorial{  
 public static void main(String args[]){  
	 Scanner s=new Scanner(System.in);
	int num,i,fact=1;
	System.out.println("enter the number to find its factorial");
	num=s.nextInt();
  for(i=1;i<=num;i++){    
      fact=fact*i;    
  }    
  System.out.println("Factorial of "+num+" is: "+fact);    
 }  
}  