import java.util.*;
public class arraycpy {
    public static void main(String args[]) {
    	int n;
    	Scanner s=new Scanner(System.in);
    	System.out.println("enter the size of an array");
    	n=s.nextInt();
        int a[]=new int[n];
    	System.out.println("enter elements of an array");
    	for(int i=0;i<n;i++)
    		a[i]=s.nextInt();
        int b[]=new int[a.length];
    	System.out.println("copied array is:");
        for (int i=0;i<a.length;i++) {
            b[i]=a[i];
        	System.out.print(" "+b[i]+",");
        }
    }
}