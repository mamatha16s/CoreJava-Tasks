import java.util.*;
public class  rhombus
{
 
    public static void main(String[] args)
    {
	Scanner s=new Scanner(System.in);
	System.out.println("enter number limit of daimond");
	int n=s.nextInt();	
	int i,j;
	for(i=1;i<=n;i++)
               {
	           for(j=1;j<=n-i;j++)
                        {
                               System.out.print(" ");
                        }
 
                      for(j=1;j<=i*2-1;j++)
                
                        {
                    	  	   if(i==2)
                               System.out.print("*");
                    	  	   else
                    	  		 System.out.print("x");
                        }
	           System.out.println();
               }            
               for(int k=n-1;k>0;k--)
               {
	                    for(int l=1;l<=n-k;l++)
                        {
                               System.out.print(" ");
                        }
                      for(int l=1;l<=k*2-1;l++)
                
                        {
                    	  if(k==2)
                    		  System.out.print("*");
               	  	   else
               	  		 System.out.print("x");
                        }
	           System.out.println();
               }   
    }
}
