import java.util.*; 
class calc
{
    public static void main(String[] args) 
    {
           
        Scanner s=new Scanner(System.in);
        System.out.println("enter your choice:\n 1: Addition \n 2: Subtraction \n 3: Multiplication \n 4: Division ");
        int i=s.nextInt();
           
        System.out.println("ENTER FIRST NUMBER ");
        int a=s.nextInt();
           
        System.out.println("ENTER SECOND NUMBER ");
        int b=s.nextInt();
           
        double result=0;
           
        switch(i)
        {
            case 1:
                result=a+b;
                break;
            case 2:
                result=a-b;
                break;
            case 3:
                result=a*b;
                break;
            case 4:
                if(b==0)
                {
                    System.out.println("DIVISION NOT POSSIBLE");
                    break;
                }
                else
                {
                    result=a/b;
                    break;
                }
            
            default:
                System.out.println("YOU HAVE ENTERED A WRONG CHOICE");
            
        }
           
        System.out.println("RESULT = "+result);
    }
}
