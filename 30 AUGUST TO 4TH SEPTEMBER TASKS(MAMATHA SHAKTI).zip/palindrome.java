import java.util.*; 
class palindrome
{
   public static void main(String args[])
   {
      String name,rev = "";
      Scanner s=new Scanner(System.in);
      System.out.println("Enter a string to check if it is a palindrome");
      name=s.nextLine();
      int length=name.length();
      for (int i=length-1;i>=0;i--)
         rev=rev+name.charAt(i);
      if (name.equals(rev))
         System.out.println("Entered string is a palindrome.");
      else
         System.out.println("Entered string is not a palindrome.");
   }
}	
