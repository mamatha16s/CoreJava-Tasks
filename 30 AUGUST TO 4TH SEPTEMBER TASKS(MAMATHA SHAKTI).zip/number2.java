import java.util.*;
class number2
{

	public static void main(String[] args) 
	{
	int num,i,j;
	Scanner s=new Scanner(System.in);
	System.out.println("enter the number to print sequence of numbers in triangle form");
	num=s.nextInt();
	for(i=1;i<=num;i++)
	{
		for(int k=num;k>=i;k--)
		{
			System.out.print(k);
		}
		System.out.println();
		
	}
	

	}

}
