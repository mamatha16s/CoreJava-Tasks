import java.util.*;
public class primenum
{
	public static void main(String[] args)
	{
		int n,i;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number to determine if it is prime or not");
		n=s.nextInt();
		for(i=2;i<=n-1;i++)
		{
			if((n%i)==0)
			{
				System.out.println(" "+n+" is not a prime number");
				break;
			}
		}
		if(i==n)
			System.out.println(" "+n+" is a prime number");
					
		}
	}

