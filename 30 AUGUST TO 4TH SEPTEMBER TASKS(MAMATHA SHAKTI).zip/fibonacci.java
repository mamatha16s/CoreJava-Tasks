public class fibonacci
{
    public static void main(String[] args)
    {
        int n=15,i=0,j=1;
        System.out.print("First " + n + " terms: ");
        for (int k=1;k<=n;++k)
        {
        	if(i<200) 
        	{
        		System.out.print(i + " + ");
        		int sum=i+j;
        		i=j;
        		j=sum;
        	}
        	else 
        		break;
        }
    }
}