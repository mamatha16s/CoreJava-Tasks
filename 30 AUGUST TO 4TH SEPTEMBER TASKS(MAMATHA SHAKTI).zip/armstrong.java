import java.util.*;
class armstrong{  
  public static void main(String[] args)  {  
    int num,i=0,j,temp;  
    Scanner s=new Scanner(System.in);
    System.out.println("enter a number to check whether it is armstrong or not");   
    num=s.nextInt();
    temp=num;  
    while(num>0)  
    {  
    j=num%10;  
    num=num/10;  
    i=i+(j*j*j);  
    }  
    if(temp==i)  
    System.out.println("True");   
    else  
        System.out.println("False");   
   }  
}  